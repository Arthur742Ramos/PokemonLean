# Supplementary Material: Formalizing Pokémon TCG in Lean 4

## Contents

- `src/` - Lean 4 source files
  - `PokemonLean/Basic.lean` - Core types and game logic
  - `PokemonLean/Semantics.lean` - Small-step semantics and legality
  - `PokemonLean/Solver.lean` - Certified damage solver
  - `PokemonLean/GameTheory.lean` - Extended strategy features
  - `PokemonLean/Cards.lean` - Sample card corpus
- `lakefile.toml` - Build configuration
- `lean-toolchain` - Lean version specification

## Building

Requires Lean 4.26.0 or later.

```bash
lake build
```

## Verifying Proofs

All theorems compile without `sorry` axioms:

```bash
lake build 2>&1 | grep -E "(error|sorry)" || echo "All proofs verified!"
```

## Key Theorems

| Theorem | File | Description |
|---------|------|-------------|
| `bestAttack_sound` | Solver.lean | Solver returns legal attack |
| `bestAttack_optimal` | Solver.lean | Solver returns damage-maximal attack |
| `reachable_card_conservation` | Semantics.lean | Card count invariant |
| `reachable_valid_initial` | Semantics.lean | Validity preserved |
| `no_turn_one_win` | Basic.lean | No T1 win possible |
| `step_total_for_legal` | Semantics.lean | Legal actions always succeed |
